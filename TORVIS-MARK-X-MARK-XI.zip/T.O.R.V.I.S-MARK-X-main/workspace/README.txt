Place project copies here for read-only Developer Studio inspection.
