"""Regression tests for Torvis safety boundaries and utility helpers."""
import importlib.util
import tempfile
import re
import unittest
import torvis_intelligence as intelligence
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("torvis_main", ROOT / "main.py")
torvis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(torvis)


class SafetyTests(unittest.TestCase):
    def setUp(self):
        self.old_cfg = dict(torvis.cfg)
        torvis.cfg["control"] = False
        torvis.cfg["shell"] = False

    def tearDown(self):
        torvis.cfg.clear()
        torvis.cfg.update(self.old_cfg)

    def test_rejects_non_http_url_schemes(self):
        for value in ("file:///etc/passwd", "javascript:alert(1)", "data:text/plain,hi"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                torvis._safe_url(value)

    def test_adds_https_to_domain(self):
        self.assertEqual(torvis._safe_url("example.com"), "https://example.com")

    def test_computer_control_is_off_by_default(self):
        result = torvis.do_action({"action": "info"}, local=True)
        self.assertFalse(result["ok"])
        self.assertIn("switched off", result["error"])

    def test_shell_actions_require_full_control(self):
        torvis.cfg["control"] = True
        result = torvis.do_action({"action": "run_command", "command": "whoami"}, local=True)
        self.assertFalse(result["ok"])
        self.assertIn("Full control", result["error"])

    def test_shell_actions_are_local_only(self):
        torvis.cfg["control"] = True
        torvis.cfg["shell"] = True
        result = torvis.do_action({"action": "run_command", "command": "whoami"}, local=False)
        self.assertFalse(result["ok"])
        self.assertIn("laptop itself", result["error"])

    def test_user_path_rejects_home_escape(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(Path, "home", return_value=Path(tmp)):
            with self.assertRaises(ValueError):
                torvis._user_path("../../outside.txt")

    def test_write_file_blocks_executable_extensions(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(Path, "home", return_value=Path(tmp)):
            result = torvis._write_file({"folder": "Documents", "filename": "payload.exe", "content": "x"})
            self.assertFalse(result["ok"])
            self.assertIn("not allowed", result["error"])

    def test_write_file_creates_unique_name_without_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(Path, "home", return_value=Path(tmp)):
            first = torvis._write_file({"folder": "Documents", "filename": "notes.txt", "content": "one"})
            second = torvis._write_file({"folder": "Documents", "filename": "notes.txt", "content": "two"})
            self.assertTrue(first["ok"])
            self.assertTrue(second["ok"])
            self.assertNotEqual(first["path"], second["path"])
            self.assertEqual(Path(first["path"]).read_text(encoding="utf-8"), "one")

    def test_screenshot_filename_is_a_path(self):
        # Regression for Path + str precedence in the screenshot-save path.
        name = torvis.time.strftime("torvis_%Y%m%d_%H%M%S_") + "123.png"
        result = torvis.PICS / name
        self.assertIsInstance(result, Path)

    def test_standalone_dashboard_matches_embedded_dashboard(self):
        source = (ROOT / "main.py").read_text(encoding="utf-8")
        match = re.search(r"INDEX_HTML = r'''(.*?)'''\n\n\nif __name__", source, re.S)
        self.assertIsNotNone(match)
        standalone = (ROOT / "torvis.html").read_text(encoding="utf-8")
        self.assertEqual(match.group(1).strip(), standalone.strip())


class IntelligenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_db, self.old_data, self.old_workspace = intelligence.DB, intelligence.DATA, intelligence.WORKSPACE
        base = Path(self.tmp.name)
        intelligence.DATA = base / "data"
        intelligence.DB = intelligence.DATA / "test.sqlite3"
        intelligence.WORKSPACE = base / "workspace"
        intelligence.WORKSPACE.mkdir()

    def tearDown(self):
        intelligence.DB, intelligence.DATA, intelligence.WORKSPACE = self.old_db, self.old_data, self.old_workspace
        self.tmp.cleanup()

    def test_memory_save_and_search(self):
        item = intelligence.memory_save("Prefers concise answers", "preference")
        self.assertEqual(intelligence.memory_list("concise")[0]["id"], item["id"])

    def test_memory_delete(self):
        item = intelligence.memory_save("Temporary note")
        self.assertTrue(intelligence.memory_delete(item["id"]))
        self.assertEqual(intelligence.memory_list(), [])

    def test_developer_workspace_blocks_path_traversal(self):
        with self.assertRaises(ValueError):
            intelligence.dev_read("../../outside.txt")

    def test_developer_studio_python_syntax_check(self):
        (intelligence.WORKSPACE / "sample.py").write_text("def hello():\n    return 1\n", encoding="utf-8")
        result = intelligence.dev_check_python("sample.py")
        self.assertTrue(result["ok"])
        self.assertEqual(result["functions"], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
