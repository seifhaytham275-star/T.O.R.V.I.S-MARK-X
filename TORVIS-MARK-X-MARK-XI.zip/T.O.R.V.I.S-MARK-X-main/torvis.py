"""Compatibility launcher for T.O.R.V.I.S MARK X."""
from main import main

if __name__ == "__main__":
    main()
