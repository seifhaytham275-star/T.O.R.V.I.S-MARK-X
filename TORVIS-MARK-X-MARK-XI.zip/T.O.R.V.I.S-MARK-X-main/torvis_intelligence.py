"""Local-first TORVIS intelligence services: persistent memory and safe developer workspace."""
from __future__ import annotations
import ast, json, os, re, sqlite3, subprocess, sys
from pathlib import Path
from typing import Any

BASE = Path(__file__).resolve().parent
DATA = BASE / 'data'
DB = DATA / 'torvis_memory.sqlite3'
WORKSPACE = BASE / 'workspace'
MAX_TEXT = 12000
BLOCKED_PARTS = {'.git', '.venv', 'venv', '__pycache__', 'node_modules', '.idea'}


def _db():
    DATA.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB, timeout=10)
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('''CREATE TABLE IF NOT EXISTS memories (
        id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL DEFAULT 'general',
        content TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
    return con


def memory_list(query: str = '', limit: int = 30) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 100))
    with _db() as con:
        if query.strip():
            rows = con.execute('SELECT id,category,content,created_at FROM memories WHERE content LIKE ? OR category LIKE ? ORDER BY updated_at DESC LIMIT ?',
                               (f'%{query[:100]}%', f'%{query[:100]}%', limit)).fetchall()
        else:
            rows = con.execute('SELECT id,category,content,created_at FROM memories ORDER BY updated_at DESC LIMIT ?', (limit,)).fetchall()
    return [dict(id=r[0], category=r[1], content=r[2], created_at=r[3]) for r in rows]


def memory_save(content: str, category: str = 'general', memory_id: int | None = None) -> dict[str, Any]:
    content = str(content).strip()[:MAX_TEXT]
    category = re.sub(r'[^\w -]', '', str(category))[:40].strip() or 'general'
    if not content:
        raise ValueError('Memory content cannot be empty')
    with _db() as con:
        if memory_id:
            cur = con.execute('UPDATE memories SET category=?,content=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', (category, content, int(memory_id)))
            if not cur.rowcount:
                raise ValueError('Memory not found')
            mid = int(memory_id)
        else:
            cur = con.execute('INSERT INTO memories(category,content) VALUES(?,?)', (category, content))
            mid = cur.lastrowid
    return {'id': mid, 'category': category, 'content': content}


def memory_delete(memory_id: int) -> bool:
    with _db() as con:
        cur = con.execute('DELETE FROM memories WHERE id=?', (int(memory_id),))
        return bool(cur.rowcount)


def _workspace() -> Path:
    WORKSPACE.mkdir(parents=True, exist_ok=True)
    return WORKSPACE.resolve()


def _safe_path(relative: str = '.') -> Path:
    root = _workspace()
    candidate = (root / str(relative)).resolve()
    if candidate != root and root not in candidate.parents:
        raise ValueError('Path is outside the TORVIS workspace')
    if any(part in BLOCKED_PARTS for part in candidate.parts):
        raise ValueError('This folder is excluded from Developer Studio')
    return candidate


def dev_tree(relative: str = '.', limit: int = 250) -> list[dict[str, Any]]:
    folder = _safe_path(relative)
    if not folder.exists() or not folder.is_dir():
        raise ValueError('Folder does not exist')
    items = []
    for p in sorted(folder.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
        if p.name in BLOCKED_PARTS or p.is_symlink():
            continue
        try:
            items.append({'name': p.name, 'path': p.relative_to(_workspace()).as_posix(), 'type': 'directory' if p.is_dir() else 'file', 'size': p.stat().st_size if p.is_file() else None})
        except OSError:
            continue
        if len(items) >= max(1, min(int(limit), 500)):
            break
    return items


def dev_read(relative: str) -> dict[str, Any]:
    p = _safe_path(relative)
    if not p.is_file():
        raise ValueError('File does not exist')
    if p.stat().st_size > 1_000_000:
        raise ValueError('File exceeds the 1 MB preview limit')
    data = p.read_bytes()
    try:
        content = data.decode('utf-8')
    except UnicodeDecodeError:
        raise ValueError('Binary or non-UTF-8 files cannot be previewed')
    return {'path': p.relative_to(_workspace()).as_posix(), 'content': content[:MAX_TEXT], 'truncated': len(content) > MAX_TEXT}


def dev_search(query: str, relative: str = '.') -> list[dict[str, Any]]:
    query = str(query).strip()[:200]
    if not query:
        raise ValueError('Search query is required')
    root = _safe_path(relative)
    if not root.is_dir():
        raise ValueError('Search location is not a folder')
    found = []
    for p in root.rglob('*'):
        if not p.is_file() or p.is_symlink() or any(x in BLOCKED_PARTS for x in p.parts):
            continue
        if p.suffix.lower() not in {'.py','.js','.ts','.tsx','.jsx','.html','.css','.json','.md','.txt','.yml','.yaml'}:
            continue
        try:
            if p.stat().st_size > 500_000: continue
            for n, line in enumerate(p.read_text(encoding='utf-8', errors='replace').splitlines(), 1):
                if query.lower() in line.lower():
                    found.append({'path': p.relative_to(_workspace()).as_posix(), 'line': n, 'text': line[:300]})
                    if len(found) >= 100: return found
        except OSError:
            pass
    return found


def dev_check_python(relative: str) -> dict[str, Any]:
    p = _safe_path(relative)
    if p.suffix.lower() != '.py' or not p.is_file():
        raise ValueError('Choose a Python source file in the workspace')
    if p.stat().st_size > 1_000_000:
        raise ValueError('File exceeds the 1 MB analysis limit')
    source = p.read_text(encoding='utf-8')
    try:
        tree = ast.parse(source, filename=p.name)
        return {'ok': True, 'path': p.relative_to(_workspace()).as_posix(), 'syntax': 'valid',
                'functions': sum(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) for n in ast.walk(tree)),
                'classes': sum(isinstance(n, ast.ClassDef) for n in ast.walk(tree)),
                'lines': len(source.splitlines())}
    except SyntaxError as exc:
        return {'ok': False, 'path': p.relative_to(_workspace()).as_posix(), 'syntax': 'error',
                'message': exc.msg, 'line': exc.lineno, 'column': exc.offset}
