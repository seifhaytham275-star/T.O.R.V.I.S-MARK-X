# T.O.R.V.I.S MARK X — Intelligence Upgrade

T.O.R.V.I.S is a local-first Python desktop assistant with a browser-based HUD. This release adds four integrated capability areas while preserving the existing interface and controls.

## The four capability areas

1. **Advanced AI Core** — Gemini model selection, conversation history, and a local SQLite memory store for notes the user explicitly asks TORVIS to remember. Saved notes are injected into relevant future prompts; they are not silently extracted from ordinary conversations.
2. **Computer Intelligence** — existing screenshot, screen observation, mouse, keyboard, application, clipboard, and optional shell tools. Computer Control and Full Control remain disabled by default. Shell commands remain behind confirmation controls.
3. **Voice Intelligence** — existing microphone capture, browser/Gemini speech recognition options, Arabic/English language handling, spoken replies, and interrupt controls.
4. **Developer Studio** — a local workspace at `workspace/` with file listing, text preview, source search, and Python syntax inspection. The initial release is read-only: it does not execute project code or modify source files. Paths are restricted to the workspace and common dependency/build folders are excluded.

## Requirements

- Python 3.10 or newer
- Windows is the primary target; some features may vary on macOS/Linux
- A Gemini API key for Gemini features
- A supported browser and user-approved microphone permission for voice input

## Install on Windows

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

You can also launch with `python torvis.py`. Use `python main.py --debug` to keep the server in the foreground and see diagnostics.

## Developer Studio

Place a project copy inside the `workspace` folder beside `main.py`. TORVIS can list files, preview supported UTF-8 text files, search source text, and parse-check Python syntax. It does not run code, install project dependencies, or write into the workspace in this release.

## Permissions and safety

On first upgrade from an older configuration, the application migrates the config to schema v2 and switches Computer Control and Full Control OFF. Enable only the permissions required for a task.

- **CONTROL** enables supported screen/input/app actions.
- **FULL CONTROL** enables local file operations and shell commands. Keep it OFF unless needed.
- Keep **ASK BEFORE COMMANDS** enabled. Review commands before approving them.
- Microphone auto-start is off unless explicitly enabled.
- Persistent memory is stored locally in `data/torvis_memory.sqlite3`; only explicitly requested notes should be saved. Do not store passwords, API keys, or sensitive personal data.
- Developer Studio is limited to the local `workspace/` folder and uses read-only operations.

The phone remote is intended only for a trusted private Wi-Fi network. Do not expose port 8123 to the public internet or configure router port forwarding. Rotate the phone code if a QR code or link is shared unintentionally.

The Gemini key is stored in the browser's local storage by the existing application design. Anyone with access to the same browser profile or Windows account may be able to access it. Do not share that profile. An OS credential vault would be preferable for a production release.

## Tests

Run the regression tests (no Gemini key or live server required):

```powershell
python -m unittest discover -s tests -v
```

## Project files

| File | Purpose |
|---|---|
| `main.py` | Main launcher, local HTTP server, desktop actions, embedded dashboard and phone remote |
| `torvis.html` | Standalone dashboard copy |
| `torvis.py` | Compatibility launcher |
| `torvis_intelligence.py` | Persistent memory and safe Developer Studio services |
| `requirements.txt` | Dependencies used by this application |
| `tests/test_safety.py` | Regression tests for security boundaries and utility helpers |

This is a tested code-level upgrade, not a security certification or a complete end-to-end test on every Windows configuration.
